package mc233.`fun`.snowygems

import mc233.`fun`.snowygems.config.GemRegistry
import mc233.`fun`.snowygems.config.MenuRegistry
import mc233.`fun`.snowygems.config.SkillRegistry
import mc233.`fun`.snowygems.manager.GemManager
import mc233.`fun`.snowygems.skill.BuffEngine
import mc233.`fun`.snowygems.util.DebugUtil
import taboolib.common.platform.Plugin
import taboolib.common.platform.function.info

object SnowyGems : Plugin() {

    val gemManager get() = GemManager

    override fun onLoad() {
        info("SnowyMC 荣誉出品")
        info("SnowyGems Loading...")
    }

    override fun onEnable() {
        info("SnowyMC 荣誉出品")
        reloadAll()
        // GemUseListener / SkillTriggerListener / MenuListener 均使用 TabooLib @SubscribeEvent, 会自动注册
        BuffEngine.start()
        info("SnowyGems 已启用")
        if (DebugUtil.enabled) {
            DebugUtil.log("Registry", "启用完成: 宝石=${GemRegistry.ids().size} 菜单=${MenuRegistry.names().size} 技能=${SkillRegistry.all().size}")
            DebugUtil.log("Registry", "点券后端=${DebugUtil.pointsProvider}")
            DebugUtil.log("Registry", "调试模式已开启, 平时请把 config.yml 的 Debug 改回 false, 否则日志量很大")
        }
    }

    override fun onDisable() {
        info("SnowyGems Disabled")
    }

    fun reloadAll() {
        DebugUtil.reload()
        GemRegistry.reload()
        MenuRegistry.reload()
        SkillRegistry.reload()
    }
}
